#! /bin/bash
open /usr/local/bin/invader
